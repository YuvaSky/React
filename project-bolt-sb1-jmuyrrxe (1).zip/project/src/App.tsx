import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import Dashboard from './pages/Dashboard';
import DonateBlood from './pages/DonateBlood';
import FindBlood from './pages/FindBlood';
import BloodCamps from './pages/BloodCamps';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import RequestBlood from './pages/RequestBlood';
import Layout from './components/layout/Layout';
import ProtectedRoute from './components/common/ProtectedRoute';
import { useNotification } from './contexts/NotificationContext';
import NotificationToast from './components/common/NotificationToast';

function App() {
  const { notifications } = useNotification();

  return (
    <>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="find-blood" element={<FindBlood />} />
          <Route path="blood-camps" element={<BloodCamps />} />
          
          <Route element={<ProtectedRoute />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="donate" element={<DonateBlood />} />
            <Route path="request" element={<RequestBlood />} />
            <Route path="profile" element={<Profile />} />
          </Route>
        </Route>
      </Routes>
      
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        {notifications.map((notification) => (
          <NotificationToast 
            key={notification.id} 
            notification={notification} 
          />
        ))}
      </div>
    </>
  );
}

export default App;