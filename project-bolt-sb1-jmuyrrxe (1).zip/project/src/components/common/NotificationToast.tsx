import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { X, Bell, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { Notification, useNotification } from '../../contexts/NotificationContext';

interface NotificationToastProps {
  notification: Notification;
}

function NotificationToast({ notification }: NotificationToastProps) {
  const { removeNotification } = useNotification();
  const [progress, setProgress] = useState(100);
  
  const duration = notification.duration || 5000;
  const isUrgent = notification.type === 'urgent';
  
  // Handle progress bar countdown
  useEffect(() => {
    if (duration === 0) return;
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev - (100 / (duration / 100));
        return newProgress < 0 ? 0 : newProgress;
      });
    }, 100);
    
    return () => clearInterval(interval);
  }, [duration]);
  
  const getIcon = () => {
    switch (notification.type) {
      case 'success':
        return <CheckCircle className="text-green-500" />;
      case 'error':
        return <AlertTriangle className="text-red-500" />;
      case 'warning':
        return <AlertTriangle className="text-amber-500" />;
      case 'urgent':
        return <Bell className="text-red-600 animate-pulse" />;
      default:
        return <Info className="text-blue-500" />;
    }
  };
  
  const getBgColor = () => {
    switch (notification.type) {
      case 'success': return 'bg-green-50 border-green-500';
      case 'error': return 'bg-red-50 border-red-500';
      case 'warning': return 'bg-amber-50 border-amber-500';
      case 'urgent': return 'bg-red-100 border-red-600';
      default: return 'bg-blue-50 border-blue-500';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
      className={`w-80 md:w-96 ${isUrgent ? 'animate-pulse-ring' : ''} ${getBgColor()} border-l-4 rounded-lg shadow-lg overflow-hidden`}
    >
      <div className="p-4 relative">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            {getIcon()}
          </div>
          <div className="flex-1">
            <p className={`text-sm font-medium ${isUrgent ? 'text-red-800' : 'text-gray-700'}`}>
              {notification.message}
            </p>
          </div>
          <button 
            onClick={() => removeNotification(notification.id)}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={18} />
          </button>
        </div>
        
        {/* Progress bar */}
        {duration !== 0 && (
          <div className="h-1 bg-gray-200 absolute bottom-0 left-0 right-0">
            <div 
              className={`h-full ${notification.type === 'urgent' ? 'bg-red-600' : 'bg-blue-500'}`}
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default NotificationToast;