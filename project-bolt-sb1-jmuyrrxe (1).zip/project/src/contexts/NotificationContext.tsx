import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'urgent';
  message: string;
  duration?: number;
}

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id'>) => void;
  removeNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function useNotification() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
}

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (notification: Omit<Notification, 'id'>) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newNotification = { ...notification, id };
    
    setNotifications(prev => [...prev, newNotification]);
    
    // Auto remove notifications after duration (default: 5000ms)
    if (notification.duration !== 0) {
      const duration = notification.duration || 5000;
      setTimeout(() => {
        removeNotification(id);
      }, duration);
    }
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  // Simulate receiving urgent blood requests (for demo purposes)
  useEffect(() => {
    const urgentRequests = [
      { 
        type: 'urgent' as const,
        message: 'URGENT: O- blood needed at City Hospital for accident victim',
        duration: 15000 
      },
      { 
        type: 'urgent' as const,
        message: 'URGENT: AB+ blood needed for surgery at Memorial Hospital',
        duration: 15000 
      }
    ];
    
    // Show first urgent request after 10 seconds
    const timeout1 = setTimeout(() => {
      addNotification(urgentRequests[0]);
    }, 10000);
    
    // Show second urgent request after 30 seconds
    const timeout2 = setTimeout(() => {
      addNotification(urgentRequests[1]);
    }, 30000);
    
    return () => {
      clearTimeout(timeout1);
      clearTimeout(timeout2);
    };
  }, []);

  const value = {
    notifications,
    addNotification,
    removeNotification
  };

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
}