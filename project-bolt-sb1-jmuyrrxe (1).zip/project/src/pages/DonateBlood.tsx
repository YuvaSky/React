import { useState } from 'react';
import { Calendar, MapPin, Heart, Clock, Info, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNotification } from '../contexts/NotificationContext';
import { useAuth } from '../contexts/AuthContext';

function DonateBlood() {
  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedCenter, setSelectedCenter] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [answers, setAnswers] = useState<{[key: string]: boolean}>({});

  // Mock donation centers
  const donationCenters = [
    {
      id: '1',
      name: 'City Blood Bank',
      address: '123 Main Street, Downtown',
      hours: '9:00 AM - 5:00 PM',
      distance: '2.3 miles'
    },
    {
      id: '2',
      name: 'Red Cross Donation Center',
      address: '456 Park Avenue, Midtown',
      hours: '8:00 AM - 7:00 PM',
      distance: '3.5 miles'
    },
    {
      id: '3',
      name: 'Community Hospital Blood Center',
      address: '789 Health Drive, Westside',
      hours: '7:00 AM - 7:00 PM',
      distance: '5.1 miles'
    }
  ];

  // Pre-screening questions for blood donation eligibility
  const eligibilityQuestions = [
    {
      id: 'q1',
      question: 'Are you between 18-65 years of age?',
      description: 'Donors must typically be within this age range for standard donations.'
    },
    {
      id: 'q2',
      question: 'Do you weigh at least 110 pounds (50 kg)?',
      description: 'Minimum weight requirement ensures donor safety.'
    },
    {
      id: 'q3',
      question: 'Are you in good health and feeling well today?',
      description: 'Donors should be in general good health without acute illness.'
    },
    {
      id: 'q4',
      question: 'Has it been more than 8 weeks since your last blood donation?',
      description: 'This is the minimum required time between whole blood donations.'
    },
    {
      id: 'q5',
      question: 'Are you free from any blood-transmissible diseases?',
      description: 'Including HIV, Hepatitis B or C, or other infectious diseases.'
    }
  ];

  const handleAnswerChange = (questionId: string, value: boolean) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const isEligible = (): boolean => {
    // Check if all questions have been answered "Yes"
    return eligibilityQuestions.every(q => answers[q.id] === true);
  };

  const getDaysArray = () => {
    const daysArray = [];
    const today = new Date();
    
    for (let i = 1; i <= 14; i++) {
      const nextDay = new Date(today);
      nextDay.setDate(today.getDate() + i);
      
      // Don't include Sundays
      if (nextDay.getDay() !== 0) {
        daysArray.push({
          date: nextDay.toISOString().split('T')[0],
          day: nextDay.toLocaleDateString('en-US', { weekday: 'short' }),
          dayNum: nextDay.getDate()
        });
      }
    }
    
    return daysArray;
  };

  const getTimeSlots = () => {
    const slots = [];
    const startHour = 9; // 9 AM
    const endHour = 17; // 5 PM
    
    for (let hour = startHour; hour <= endHour; hour++) {
      // Add slots every 30 minutes
      slots.push(`${hour}:00`);
      if (hour < endHour) {
        slots.push(`${hour}:30`);
      }
    }
    
    return slots.map(time => {
      const [hours, minutes] = time.split(':');
      const hour = parseInt(hours);
      const period = hour >= 12 ? 'PM' : 'AM';
      const displayHour = hour % 12 === 0 ? 12 : hour % 12;
      return `${displayHour}:${minutes} ${period}`;
    });
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    
    // Simulate API call for appointment booking
    setTimeout(() => {
      addNotification({
        type: 'success',
        message: 'Your donation appointment has been scheduled successfully!'
      });
      setIsSubmitting(false);
      setStep(4); // Move to confirmation step
    }, 1500);
  };

  const handleContinue = () => {
    if (step === 1 && isEligible()) {
      setStep(2);
    } else if (step === 2 && selectedCenter) {
      setStep(3);
    } else if (step === 3 && selectedDate && selectedTime) {
      handleSubmit();
    }
  };

  const renderEligibilityStep = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Pre-Donation Eligibility Check</h2>
        <p className="text-gray-600 mb-6">
          Please answer these questions to determine if you're eligible to donate blood today.
        </p>
        
        <div className="space-y-6">
          {eligibilityQuestions.map((q) => (
            <div key={q.id} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-start gap-3">
                <div className="pt-1">
                  <Info size={18} className="text-blue-500" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-800 mb-1">{q.question}</h3>
                  <p className="text-sm text-gray-600 mb-3">{q.description}</p>
                  
                  <div className="flex gap-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name={q.id}
                        checked={answers[q.id] === true}
                        onChange={() => handleAnswerChange(q.id, true)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300"
                      />
                      <span className="ml-2 text-sm">Yes</span>
                    </label>
                    
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name={q.id}
                        checked={answers[q.id] === false}
                        onChange={() => handleAnswerChange(q.id, false)}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300"
                      />
                      <span className="ml-2 text-sm">No</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {eligibilityQuestions.every(q => answers[q.id] !== undefined) && (
        <div className={`bg-white rounded-lg shadow-md p-6 border-l-4 ${isEligible() ? 'border-green-500' : 'border-red-500'}`}>
          <div className="flex items-start gap-3">
            <div className="pt-1">
              {isEligible() ? (
                <CheckCircle size={20} className="text-green-500" />
              ) : (
                <AlertTriangle size={20} className="text-red-500" />
              )}
            </div>
            <div>
              <h3 className="font-medium text-gray-800">
                {isEligible()
                  ? "You're eligible to donate blood!"
                  : "You may not be eligible to donate blood at this time."}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {isEligible()
                  ? "Please proceed to select a donation center."
                  : "Please review your answers or consult with a healthcare professional for more information."}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex justify-end">
        <button
          onClick={handleContinue}
          disabled={!isEligible()}
          className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors hover:bg-red-700"
        >
          Continue
        </button>
      </div>
    </div>
  );

  const renderLocationStep = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Select Donation Center</h2>
        <p className="text-gray-600 mb-6">
          Choose a blood donation center near you for your appointment.
        </p>
        
        <div className="space-y-4">
          {donationCenters.map((center) => (
            <div
              key={center.id}
              onClick={() => setSelectedCenter(center.id)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedCenter === center.id
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-200 hover:border-red-200'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-gray-800">{center.name}</h3>
                  <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                    <MapPin size={14} />
                    <span>{center.address}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                    <Clock size={14} />
                    <span>{center.hours}</span>
                  </div>
                </div>
                <div className="bg-gray-100 px-2 py-1 rounded text-sm">
                  {center.distance}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-between">
        <button
          onClick={() => setStep(1)}
          className="px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg transition-colors hover:bg-gray-50"
        >
          Back
        </button>
        <button
          onClick={handleContinue}
          disabled={!selectedCenter}
          className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors hover:bg-red-700"
        >
          Continue
        </button>
      </div>
    </div>
  );

  const renderScheduleStep = () => {
    const days = getDaysArray();
    const timeSlots = getTimeSlots();
    
    return (
      <div className="space-y-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Schedule Your Appointment</h2>
          <p className="text-gray-600 mb-6">
            Select a date and time for your blood donation appointment.
          </p>
          
          <div className="mb-6">
            <h3 className="font-medium text-gray-700 mb-3">
              Select Date
            </h3>
            <div className="grid grid-cols-3 md:grid-cols-7 gap-2">
              {days.map((day) => (
                <div
                  key={day.date}
                  onClick={() => setSelectedDate(day.date)}
                  className={`p-3 rounded-lg border text-center cursor-pointer transition-all ${
                    selectedDate === day.date
                      ? 'border-red-500 bg-red-50'
                      : 'border-gray-200 hover:border-red-200'
                  }`}
                >
                  <p className="text-xs text-gray-500">{day.day}</p>
                  <p className={`text-lg font-medium ${
                    selectedDate === day.date ? 'text-red-600' : 'text-gray-800'
                  }`}>
                    {day.dayNum}
                  </p>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-700 mb-3">
              Select Time
            </h3>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
              {timeSlots.map((time) => (
                <div
                  key={time}
                  onClick={() => setSelectedTime(time)}
                  className={`py-2 px-3 rounded-lg border text-center cursor-pointer transition-all ${
                    selectedTime === time
                      ? 'border-red-500 bg-red-50'
                      : 'border-gray-200 hover:border-red-200'
                  }`}
                >
                  <p className={`text-sm ${
                    selectedTime === time ? 'text-red-600 font-medium' : 'text-gray-800'
                  }`}>
                    {time}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button
            onClick={() => setStep(2)}
            className="px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg transition-colors hover:bg-gray-50"
          >
            Back
          </button>
          <button
            onClick={handleContinue}
            disabled={!selectedDate || !selectedTime}
            className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors hover:bg-red-700"
          >
            Schedule Appointment
          </button>
        </div>
      </div>
    );
  };

  const renderConfirmationStep = () => {
    const center = donationCenters.find(c => c.id === selectedCenter);
    const date = new Date(selectedDate);
    const formattedDate = date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
          <div className="flex items-start gap-4">
            <div className="bg-green-100 p-3 rounded-full">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">Appointment Scheduled Successfully!</h2>
              <p className="text-gray-600">
                Thank you for scheduling your blood donation. Your contribution can save up to 3 lives!
              </p>
              
              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-800 mb-2">Appointment Details</h3>
                <ul className="space-y-2">
                  <li className="flex gap-2">
                    <Calendar size={18} className="text-red-600 flex-shrink-0" />
                    <span>{formattedDate} at {selectedTime}</span>
                  </li>
                  <li className="flex gap-2">
                    <MapPin size={18} className="text-red-600 flex-shrink-0" />
                    <span>{center?.name}, {center?.address}</span>
                  </li>
                </ul>
              </div>
              
              <div className="mt-6">
                <h3 className="font-medium text-gray-800 mb-2">What to bring:</h3>
                <ul className="list-disc ml-5 text-gray-600 space-y-1">
                  <li>A valid photo ID</li>
                  <li>List of medications you're currently taking</li>
                  <li>Drink plenty of water before your appointment</li>
                  <li>Have a light meal before donating</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-center">
          <button
            onClick={() => setStep(1)}
            className="px-4 py-2 border border-red-600 text-red-600 font-medium rounded-lg transition-colors hover:bg-red-50"
          >
            Schedule Another Donation
          </button>
        </div>
      </motion.div>
    );
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return renderEligibilityStep();
      case 2:
        return renderLocationStep();
      case 3:
        return renderScheduleStep();
      case 4:
        return renderConfirmationStep();
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-red-600 mb-2">Donate Blood</h1>
          <p className="text-gray-600">
            Schedule your blood donation appointment and help save lives.
          </p>
        </div>
        
        {step < 4 && (
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {[1, 2, 3].map((stepNumber) => (
                <div key={stepNumber} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full ${
                      step >= stepNumber ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {stepNumber}
                  </div>
                  <div className={`hidden sm:block ml-2 text-sm ${
                    step >= stepNumber ? 'text-gray-800 font-medium' : 'text-gray-500'
                  }`}>
                    {stepNumber === 1 && 'Eligibility'}
                    {stepNumber === 2 && 'Location'}
                    {stepNumber === 3 && 'Schedule'}
                  </div>
                  
                  {stepNumber < 3 && (
                    <div className={`w-24 sm:w-32 md:w-40 h-1 mx-2 ${
                      step > stepNumber ? 'bg-red-600' : 'bg-gray-200'
                    }`}></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {renderStepContent()}
      </div>
      
      {step < 4 && (
        <div className="mt-16 bg-gray-50 rounded-lg p-6 max-w-3xl mx-auto">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Heart size={18} className="text-red-600" fill="#E53E3E" />
            Why Your Donation Matters
          </h3>
          <p className="text-gray-600 mb-4">
            Every two seconds, someone in the country needs blood. Your donation can help:
          </p>
          <ul className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <p className="font-medium text-gray-800 mb-1">Accident Victims</p>
              <p className="text-sm text-gray-600">A single car accident victim can require up to 100 units of blood.</p>
            </li>
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <p className="font-medium text-gray-800 mb-1">Cancer Patients</p>
              <p className="text-sm text-gray-600">Many cancer patients need blood transfusions during chemotherapy.</p>
            </li>
            <li className="bg-white p-4 rounded-lg shadow-sm">
              <p className="font-medium text-gray-800 mb-1">Surgical Patients</p>
              <p className="text-sm text-gray-600">Surgeries often require blood transfusions to replace lost blood.</p>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
}

export default DonateBlood;