import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Droplets, Search, MapPin, Heart, Users, Clock, Award, CheckCircle } from 'lucide-react';

function HomePage() {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen bg-gradient-to-br from-red-50 to-white overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute w-96 h-96 bg-red-200 rounded-full -top-12 -right-16 opacity-20"></div>
          <div className="absolute w-80 h-80 bg-red-200 rounded-full bottom-0 -left-10 opacity-30"></div>
        </div>
        
        <div className="container mx-auto px-4 h-full flex items-center relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial="hidden"
              animate="visible"
              variants={fadeIn}
            >
              <h5 className="text-red-600 font-medium mb-4 flex items-center">
                <Heart size={18} className="mr-2" fill="#E53E3E" />
                DONATE BLOOD, SAVE LIVES
              </h5>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Connect Blood <span className="text-red-600">Donors</span> With Those In Need
              </h1>
              <p className="text-lg text-gray-600 mb-8 max-w-lg">
                DonorCircle helps you quickly find blood donors or donate blood to someone in need. Join our community and help save lives.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/find-blood" className="btn-primary">
                  Find Blood
                </Link>
                <Link to="/register" className="btn-outline">
                  Become a Donor
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              className="hidden lg:block"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <img 
                src="https://images.pexels.com/photos/6823517/pexels-photo-6823517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Blood donation" 
                className="w-full h-auto rounded-2xl shadow-2xl"
              />
            </motion.div>
          </div>
        </div>
        
        {/* Stats */}
        <div className="absolute bottom-0 left-0 right-0 bg-white shadow-md py-4">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <h3 className="text-3xl font-bold text-red-600">10,000+</h3>
                <p className="text-gray-600">Registered Donors</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <h3 className="text-3xl font-bold text-red-600">15,000+</h3>
                <p className="text-gray-600">Lives Saved</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                <h3 className="text-3xl font-bold text-red-600">1,000+</h3>
                <p className="text-gray-600">Blood Camps</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <h3 className="text-3xl font-bold text-red-600">500+</h3>
                <p className="text-gray-600">Partner Hospitals</p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How DonorCircle Works
            </h2>
            <p className="text-lg text-gray-600">
              Our platform makes it easy to find or donate blood. Here's how you can get started.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <motion.div 
              className="card text-center px-6 py-8 h-full flex flex-col items-center"
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "0px 0px -100px 0px" }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-red-100 p-4 rounded-full mb-6">
                <Search className="text-red-600" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Find Blood</h3>
              <p className="text-gray-600 mb-6">
                Search for blood donors based on blood type, location, and urgency level. Connect directly with willing donors near you.
              </p>
              <Link to="/find-blood" className="mt-auto btn-outline">
                Find Donors
              </Link>
            </motion.div>
            
            <motion.div 
              className="card text-center px-6 py-8 h-full flex flex-col items-center"
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "0px 0px -100px 0px" }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-red-100 p-4 rounded-full mb-6">
                <Droplets className="text-red-600" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Donate Blood</h3>
              <p className="text-gray-600 mb-6">
                Register as a donor and respond to donation requests. Set your availability and the types of donations you're willing to make.
              </p>
              <Link to="/donate" className="mt-auto btn-outline">
                Become a Donor
              </Link>
            </motion.div>
            
            <motion.div 
              className="card text-center px-6 py-8 h-full flex flex-col items-center"
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "0px 0px -100px 0px" }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="bg-red-100 p-4 rounded-full mb-6">
                <MapPin className="text-red-600" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Find Blood Camps</h3>
              <p className="text-gray-600 mb-6">
                Locate blood donation camps and drives near you. View schedules, requirements, and register to participate.
              </p>
              <Link to="/blood-camps" className="mt-auto btn-outline">
                Find Camps
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Blood Types Info Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Understanding Blood Types
            </h2>
            <p className="text-lg text-gray-600">
              Blood type compatibility is crucial for successful transfusions. Learn about different blood types and their compatibility.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((type, index) => (
              <motion.div 
                key={type}
                className="card text-center"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "0px 0px -100px 0px" }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <div className="mb-4">
                  <span className="blood-type-badge w-16 h-16 text-xl">
                    {type}
                  </span>
                </div>
                <h4 className="text-lg font-bold mb-2">Type {type}</h4>
                <p className="text-gray-600 mb-2">
                  {type === 'O-' ? 'Universal donor' : 
                   type === 'AB+' ? 'Universal recipient' : 
                   `Compatible with ${type.includes('O') ? 'many' : 'some'} blood types`}
                </p>
                <a href="#" className="text-red-600 hover:underline text-sm">
                  See compatibility chart
                </a>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/find-blood" className="btn-primary">
              Find Your Blood Type
            </Link>
          </div>
        </div>
      </section>
      
      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why Choose DonorCircle?
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Our platform offers unique advantages for blood donors and recipients, making the donation process smooth and efficient.
              </p>
              
              <div className="space-y-6">
                <motion.div 
                  className="flex gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="bg-red-100 p-3 rounded-full h-min">
                    <Clock className="text-red-600" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Quick Response Time</h3>
                    <p className="text-gray-600">
                      Our platform connects you with nearby donors in minutes, critical in emergency situations.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <div className="bg-red-100 p-3 rounded-full h-min">
                    <Users className="text-red-600" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Large Donor Network</h3>
                    <p className="text-gray-600">
                      Access thousands of verified donors across the country, increasing your chances of finding the right match.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-red-100 p-3 rounded-full h-min">
                    <CheckCircle className="text-red-600" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Verified Donors</h3>
                    <p className="text-gray-600">
                      All donors are verified with medical history and donation eligibility checks for your safety.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <div className="bg-red-100 p-3 rounded-full h-min">
                    <Award className="text-red-600" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Recognition System</h3>
                    <p className="text-gray-600">
                      Donors earn badges and recognition for their life-saving contributions, building a community of heroes.
                    </p>
                  </div>
                </motion.div>
              </div>
            </div>
            
            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/8460158/pexels-photo-8460158.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Blood donation process" 
                className="w-full h-auto rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-8 -left-8 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-red-100 p-2 rounded-full">
                    <Heart className="text-red-600" size={24} fill="#E53E3E" />
                  </div>
                  <div>
                    <p className="text-gray-500 text-sm">Lives Saved Last Month</p>
                    <p className="text-xl font-bold text-gray-900">1,247</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-red-600 to-red-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Make a Difference?
          </h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto mb-8">
            Join thousands of donors who are saving lives every day. Your donation can make a world of difference.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/register" className="px-6 py-3 bg-white text-red-600 font-bold rounded-lg hover:bg-gray-100 transition-colors">
              Become a Donor
            </Link>
            <Link to="/find-blood" className="px-6 py-3 bg-transparent border-2 border-white text-white font-bold rounded-lg hover:bg-white/10 transition-colors">
              Find Blood
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;