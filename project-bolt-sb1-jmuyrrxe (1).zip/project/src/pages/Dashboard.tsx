import React from 'react';
import { Heart, Droplet, Calendar, Clock } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-red-600 mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-red-500">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-red-100 mr-4">
              <Droplet className="h-6 w-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Blood Type</p>
              <p className="text-xl font-semibold">A+</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-green-500">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 mr-4">
              <Heart className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Donations</p>
              <p className="text-xl font-semibold">3</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100 mr-4">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Next Eligible Date</p>
              <p className="text-xl font-semibold">June 15, 2025</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 border-l-4 border-purple-500">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 mr-4">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Last Donation</p>
              <p className="text-xl font-semibold">3 months ago</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Activities</h2>
        <div className="divide-y">
          <div className="py-3">
            <p className="font-medium">Blood Donation</p>
            <p className="text-sm text-gray-500">City Hospital - March 10, 2025</p>
          </div>
          <div className="py-3">
            <p className="font-medium">Appointment Scheduled</p>
            <p className="text-sm text-gray-500">Red Cross Center - June 15, 2025</p>
          </div>
          <div className="py-3">
            <p className="font-medium">Profile Updated</p>
            <p className="text-sm text-gray-500">Contact information - February 20, 2025</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Upcoming Blood Camps</h2>
        <div className="divide-y">
          <div className="py-3">
            <p className="font-medium">Community Center Blood Drive</p>
            <p className="text-sm text-gray-500">May 5, 2025 - 9:00 AM to 4:00 PM</p>
            <p className="text-sm text-gray-600 mt-1">123 Main Street, Downtown</p>
          </div>
          <div className="py-3">
            <p className="font-medium">University Blood Donation Event</p>
            <p className="text-sm text-gray-500">May 12, 2025 - 10:00 AM to 3:00 PM</p>
            <p className="text-sm text-gray-600 mt-1">Student Center, State University</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;