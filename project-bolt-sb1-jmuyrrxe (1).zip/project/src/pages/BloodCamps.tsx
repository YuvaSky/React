import React from 'react';
import { Calendar, MapPin, Clock } from 'lucide-react';

const BloodCamps: React.FC = () => {
  // Sample blood camp data - in a real app this would come from an API
  const bloodCamps = [
    {
      id: 1,
      name: 'City General Hospital Blood Drive',
      location: '123 Main Street, Downtown',
      date: 'June 15, 2025',
      time: '9:00 AM - 5:00 PM',
      description: 'Regular blood donation camp organized by City General Hospital.',
    },
    {
      id: 2,
      name: 'University Health Center Blood Drive',
      location: 'University Campus, Building B',
      date: 'June 20, 2025',
      time: '10:00 AM - 4:00 PM',
      description: 'Special blood donation event for students and faculty.',
    },
    {
      id: 3,
      name: 'Community Center Blood Drive',
      location: '789 Park Avenue, Westside',
      date: 'June 25, 2025',
      time: '8:00 AM - 3:00 PM',
      description: 'Community blood donation event with free health checkups.',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-red-600 mb-6">Blood Donation Camps</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Find Blood Donation Camps Near You</h2>
        <p className="text-gray-600 mb-4">
          Attend a blood donation camp to contribute to saving lives. Below is a list of upcoming blood donation
          camps in your area.
        </p>
        
        <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-4">
          <div className="flex-1">
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input
              type="text"
              id="location"
              placeholder="Enter your city or area"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
            />
          </div>
          <div className="flex-1">
            <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Date</label>
            <input
              type="date"
              id="date"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
            />
          </div>
          <div className="mt-6">
            <button className="w-full md:w-auto bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors">
              Search Camps
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {bloodCamps.map((camp) => (
          <div key={camp.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow">
            <div className="p-5">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{camp.name}</h3>
              <p className="text-gray-600 mb-4">{camp.description}</p>
              
              <div className="flex items-center text-gray-700 mb-2">
                <MapPin className="h-5 w-5 text-red-500 mr-2" />
                <span>{camp.location}</span>
              </div>
              
              <div className="flex items-center text-gray-700 mb-2">
                <Calendar className="h-5 w-5 text-red-500 mr-2" />
                <span>{camp.date}</span>
              </div>
              
              <div className="flex items-center text-gray-700 mb-4">
                <Clock className="h-5 w-5 text-red-500 mr-2" />
                <span>{camp.time}</span>
              </div>
              
              <button className="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 transition-colors">
                Register to Donate
              </button>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 bg-red-50 border border-red-100 rounded-lg p-6">
        <h2 className="text-xl font-semibold text-red-600 mb-4">Organize a Blood Donation Camp</h2>
        <p className="text-gray-700 mb-4">
          If you're interested in organizing a blood donation camp at your institution, workplace, or community,
          please contact us. We provide all necessary equipment and medical staff.
        </p>
        <button className="bg-red-600 text-white py-2 px-6 rounded-md hover:bg-red-700 transition-colors">
          Contact Us
        </button>
      </div>
    </div>
  );
};

export default BloodCamps;